package com.example.beuty

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
